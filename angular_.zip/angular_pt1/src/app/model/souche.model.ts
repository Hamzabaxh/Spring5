export class Souche {
    idSou! : number; // ou idCat? : number;
    nomSou! : string;
    descriptionSou! : string;
    }
    