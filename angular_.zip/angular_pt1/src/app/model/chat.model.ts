import { Souche } from "./souche.model";

export class Chat {
    idChat? : number;
    nomChat? : string;
    prixAdoption? : number;
    datenaissance? : Date ;
    souche? : Souche;
    }